import React from 'react';  
import '../App.css';  



export default class PageNumbers extends React.Component {
    renderPageNumbers(pageNumbers){
    var linkString = "&perPage=" + this.state.perpage;
    if(this.state.objectFilter && this.state.objectFilter.length > 1){
      linkString = linkString + "&object=" + encodeURIComponent(this.state.objectFilter);
    }
    if(this.state.dateFrom.length > 5){
      linkString = linkString + "&dateFrom=" + this.state.dateFrom;
    }
    if(this.state.dateTo.length > 5){
      linkString = linkString + "&dateTo=" + this.state.dateTo;
    }

    return pageNumbers.map(nums => (
      <li key={nums}><a href={"./?page=" + nums + linkString} className="pagelink">{nums}</a></li> 
    ))
  }
    
    render() {
        var linkString = "&perPage=";
        console.log(this.props.totalPages);
        var pageNumbers = [];
        if (this.props.totalPages !== null) {
          for (let i = 1; i <= this.props.totalPages; i++) {
            pageNumbers.push(i);
          }
        }
      
        return(
            pageNumbers.map(nums => (
                <li key={nums}><a href={"./?page=" + nums + linkString} className=
                {nums == this.props.currentPage ? "pagecurrent" : "pagelink"}  
              >{nums}</a></li>  


        ))
        )  
    }

}

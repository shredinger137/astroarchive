export const config = {
    api: 'http://gtn.sonoma.edu/api'
}
<?php

	$commands = shell_exec('sudo ./deploy.sh');
		
?>
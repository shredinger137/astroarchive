module.exports.dbname = "gortarchive";
module.exports.dbuser = "gtn";
module.exports.dbpassword = "1qazXSW@3edc";
module.exports.dbhost = "localhost";